package pl.project.budgetassistant.exceptions;

public class NumberRangeException extends Exception {
    public NumberRangeException(String text) {
        super(text);
    }
}
