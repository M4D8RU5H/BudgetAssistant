package pl.project.budgetassistant.libraries;


public interface OnRevealAnimationListener {
    void onRevealHide();
    void onRevealShow();
}